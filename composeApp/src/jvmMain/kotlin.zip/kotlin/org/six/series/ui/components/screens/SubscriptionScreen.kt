package org.six.series.ui.components.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.koin.compose.viewmodel.koinViewModel
import org.six.series.model.payment.Payment
import org.six.series.model.payment.PaymentMethod
import org.six.series.model.payment.PaymentStatus
import org.six.series.model.subscription.Subscription
import org.six.series.model.subscription.SubscriptionStatus
import org.six.series.model.subscription.SubscriptionType
import org.six.series.model.subscription.subscriptionPlans
import org.six.series.profileButtonColors
import org.six.series.ui.components.viewmodels.SubscriptionUiState
import org.six.series.ui.components.viewmodels.SubscriptionViewModel

@Composable
fun SubscriptionScreen(
    viewModel: SubscriptionViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val showPaymentDialog by viewModel.showPaymentDialog.collectAsState()
    val pendingType by viewModel.pendingType.collectAsState()
    val actionMessage by viewModel.actionMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val primaryColor = MaterialTheme.colorScheme.primary
    LaunchedEffect(Unit) {
        viewModel.load()
    }
    LaunchedEffect(actionMessage) {
        actionMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { padding ->
        when (uiState) {
            is SubscriptionUiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            }
            is SubscriptionUiState.Error -> {
                val msg = (uiState as SubscriptionUiState.Error).message
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(msg, color = MaterialTheme.colorScheme.error)
                        Button(onClick = { viewModel.load() }, colors = profileButtonColors()) { Text("Reintentar") }
                    }
                }
            }
            is SubscriptionUiState.Success -> {
                val data = uiState as SubscriptionUiState.Success
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 32.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    Text(
                        "Suscripción",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryColor
                    )

                    // ── Current subscription status ──
                    CurrentSubscriptionCard(
                        subscription = data.subscription,
                        onCancel = { viewModel.cancelSubscription() }
                    )

                    // ── Plan selector (only if no active sub) ──
                    if (data.subscription?.status != SubscriptionStatus.Active) {
                        Text(
                            "Elige tu plan",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        subscriptionPlans.forEach { plan ->
                            PlanCard(
                                displayName = plan.displayName,
                                priceMonthly = plan.priceMonthly,
                                priceYearly = plan.priceYearly,
                                features = plan.features,
                                onSubscribeMonthly = { viewModel.requestSubscription(plan.type) },
                                onSubscribeYearly = {
                                    val yearlyType = if (plan.type == SubscriptionType.Standard)
                                        SubscriptionType.StandardYearly else SubscriptionType.PremiumYearly
                                    viewModel.requestSubscription(yearlyType)
                                }
                            )
                        }
                    }

                    // ── Payment history ──
                    if (data.payments.isNotEmpty()) {
                        Text(
                            "Historial de pagos",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        data.payments.forEach { payment ->
                            PaymentHistoryItem(payment)
                        }
                    }
                }
            }
        }
    }

    // ── Payment method dialog ──
    if (showPaymentDialog && pendingType != null) {
        PaymentMethodDialog(
            subscriptionType = pendingType!!,
            onConfirm = { method -> viewModel.confirmPayment(method) },
            onDismiss = { viewModel.dismissPaymentDialog() }
        )
    }
}

@Composable
fun CurrentSubscriptionCard(subscription: Subscription?, onCancel: () -> Unit) {
    val primaryColor = MaterialTheme.colorScheme.primary
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Estado actual", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (subscription == null) {
                Text("Sin suscripción activa", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val statusColor = when (subscription.status) {
                    SubscriptionStatus.Active -> Color(0xFF4CAF50)
                    SubscriptionStatus.Pending -> Color(0xFFFFC107)
                    SubscriptionStatus.Expired -> MaterialTheme.colorScheme.error
                }
                val statusLabel = when (subscription.status) {
                    SubscriptionStatus.Active -> "Activa"
                    SubscriptionStatus.Pending -> "Pendiente"
                    SubscriptionStatus.Expired -> "Expirada"
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.size(10.dp).background(statusColor, shape = RoundedCornerShape(50)))
                    Text(statusLabel, color = statusColor, fontWeight = FontWeight.Bold)
                }
                val planName = when (subscription.type) {
                    SubscriptionType.Standard -> "Estándar Mensual"
                    SubscriptionType.Premium -> "Premium Mensual"
                    SubscriptionType.StandardYearly -> "Estándar Anual"
                    SubscriptionType.PremiumYearly -> "Premium Anual"
                }
                Text("Plan: $planName")
                Text("Válida hasta: ${subscription.endDate}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (subscription.status == SubscriptionStatus.Active) {
                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = onCancel,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = ButtonDefaults.outlinedButtonBorder.copy()
                    ) { Text("Cancelar suscripción") }
                }
            }
        }
    }
}

@Composable
fun PlanCard(
    displayName: String,
    priceMonthly: Float,
    priceYearly: Float,
    features: List<String>,
    onSubscribeMonthly: () -> Unit,
    onSubscribeYearly: () -> Unit
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    Card(
        modifier = Modifier.fillMaxWidth()
            .border(1.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(displayName, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = primaryColor)
            features.forEach { feature ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✓", color = primaryColor, fontWeight = FontWeight.Bold)
                    Text(feature, fontSize = 14.sp)
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onSubscribeMonthly,
                    modifier = Modifier.weight(1f),
                    colors = profileButtonColors(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${String.format("%.2f", priceMonthly)} €/mes", fontWeight = FontWeight.Bold)
                        Text("Mensual", fontSize = 11.sp)
                    }
                }
                OutlinedButton(
                    onClick = onSubscribeYearly,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryColor)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${String.format("%.2f", priceYearly)} €/año", fontWeight = FontWeight.Bold)
                        Text("Ahorra ${(priceMonthly * 12 - priceYearly).toInt()}€", fontSize = 11.sp, color = Color(0xFF4CAF50))
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentHistoryItem(payment: Payment) {
    val statusColor = when (payment.status) {
        PaymentStatus.Completed -> Color(0xFF4CAF50)
        PaymentStatus.Pending   -> Color(0xFFFFC107)
        PaymentStatus.Failed    -> MaterialTheme.colorScheme.error
    }
    val statusLabel = when (payment.status) {
        PaymentStatus.Completed -> "Completado"
        PaymentStatus.Pending   -> "Pendiente"
        PaymentStatus.Failed    -> "Fallido"
    }
    val methodLabel = when (payment.method) {
        PaymentMethod.Card   -> "💳 Tarjeta"
        PaymentMethod.PayPal -> "🅿 PayPal"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(payment.paymentDate, fontWeight = FontWeight.Medium)
                Text(methodLabel, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${String.format("%.2f", payment.amount)} €", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(statusLabel, color = statusColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun PaymentMethodDialog(
    subscriptionType: SubscriptionType,
    onConfirm: (PaymentMethod) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedMethod by remember { mutableStateOf(PaymentMethod.Card) }
    val primaryColor = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Método de pago", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = primaryColor)

                val planLabel = when (subscriptionType) {
                    SubscriptionType.Standard -> "Estándar Mensual — 7.99 €"
                    SubscriptionType.Premium -> "Premium Mensual — 13.99 €"
                    SubscriptionType.StandardYearly -> "Estándar Anual — 79.99 €"
                    SubscriptionType.PremiumYearly -> "Premium Anual — 139.99 €"
                }
                Text(planLabel, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                HorizontalDivider()

                // Card option
                PaymentMethodOption(
                    label = "💳 Tarjeta de crédito / débito",
                    isSelected = selectedMethod == PaymentMethod.Card,
                    onSelect = { selectedMethod = PaymentMethod.Card }
                )
                // PayPal option
                PaymentMethodOption(
                    label = "🅿 PayPal",
                    isSelected = selectedMethod == PaymentMethod.PayPal,
                    onSelect = { selectedMethod = PaymentMethod.PayPal }
                )

                Spacer(Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) { Text("Cancelar") }
                    Button(
                        onClick = { onConfirm(selectedMethod) },
                        modifier = Modifier.weight(1f),
                        colors = profileButtonColors()
                    ) { Text("Confirmar pago") }
                }
            }
        }
    }
}

@Composable
fun PaymentMethodOption(label: String, isSelected: Boolean, onSelect: () -> Unit) {
    val primaryColor = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) primaryColor else Color.Gray.copy(alpha = 0.3f),
                shape = RoundedCornerShape(10.dp)
            )
            .background(
                if (isSelected) primaryColor.copy(alpha = 0.07f) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RadioButton(
            selected = isSelected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(selectedColor = primaryColor)
        )
        Text(label, fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
    }
}
