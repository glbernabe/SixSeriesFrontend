package org.six.series.ui.components.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.github.vinceglb.filekit.PlatformFile
import io.github.vinceglb.filekit.readBytes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.six.series.application.usecases.profile.GetMyProfilesUseCase
import org.six.series.application.usecases.profile.UpdateProfileUseCase
import org.six.series.application.usecases.profile.UploadAvatarUseCase
import org.six.series.model.profile.Profile
import org.six.series.model.profile.ProfileUpdateRequest
import org.six.series.ui.appsettings.AppSettings
import org.six.series.ui.appsettings.AppViewModel

sealed class ProfileUiState {
    object Loading : ProfileUiState()
    data class Success(val profile: Profile) : ProfileUiState()
    data class Error(val message: String) : ProfileUiState()
}

class ProfileViewModel(
    private val getMyProfilesUseCase: GetMyProfilesUseCase,
    private val updateProfileUseCase: UpdateProfileUseCase,
    private val uploadAvatarUseCase: UploadAvatarUseCase,
    private val appViewModel: AppViewModel
) : ViewModel() {

    private val _uiState = MutableStateFlow<ProfileUiState>(ProfileUiState.Loading)
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    private val _selectedFile = MutableStateFlow<PlatformFile?>(null)
    val selectedFile: StateFlow<PlatformFile?> = _selectedFile.asStateFlow()

    private val _saveSuccess = MutableStateFlow<String?>(null)
    val saveSuccess: StateFlow<String?> = _saveSuccess.asStateFlow()

    init {}

    fun loadProfile() {
        viewModelScope.launch {
            _uiState.value = ProfileUiState.Loading
            getMyProfilesUseCase()
                .onSuccess { profiles ->
                    val profile = profiles.firstOrNull()
                    if (profile != null) {
                        _uiState.value = ProfileUiState.Success(profile)
                        // Sync saved color from profile if server has one
                        profile.themeColor?.let { hex ->
                            runCatching {
                                val colorLong = hex.removePrefix("#").toLong(16) or 0xFF000000L
                                appViewModel.updateAppColor(colorLong)
                            }
                        }
                    } else {
                        _uiState.value = ProfileUiState.Error("No se encontró ningún perfil")
                    }
                }
                .onFailure {
                    _uiState.value = ProfileUiState.Error("Error al cargar el perfil")
                }
        }
    }

    fun selectFile(file: PlatformFile?) {
        _selectedFile.value = file
    }

    fun updateColor(colorLong: Long) {
        appViewModel.updateAppColor(colorLong)
        // Also persist on profile if we have one
        val state = _uiState.value
        if (state is ProfileUiState.Success) {
            viewModelScope.launch {
                val hexColor = "#%06X".format(colorLong and 0xFFFFFF)
                updateProfileUseCase(
                    state.profile.id,
                    ProfileUpdateRequest(name = state.profile.name, themeColor = hexColor)
                )
            }
        }
    }

    fun saveChanges(newName: String) {
        val state = _uiState.value as? ProfileUiState.Success ?: return
        viewModelScope.launch {
            val file = _selectedFile.value
            // Upload avatar first if selected
            if (file != null) {
                val bytes = file.readBytes()
                uploadAvatarUseCase(state.profile.id, bytes, "image/jpeg")
                    .onFailure {
                        _saveSuccess.value = "Error al subir la foto de perfil"
                        return@launch
                    }
                _selectedFile.value = null
            }
            // Update name
            updateProfileUseCase(
                state.profile.id,
                ProfileUpdateRequest(name = newName)
            ).onSuccess { updated ->
                _uiState.value = ProfileUiState.Success(updated)
                _saveSuccess.value = "Perfil guardado correctamente"
            }.onFailure {
                _saveSuccess.value = "Error al guardar el perfil"
            }
        }
    }

    fun dismissSaveMessage() { _saveSuccess.value = null }
}
