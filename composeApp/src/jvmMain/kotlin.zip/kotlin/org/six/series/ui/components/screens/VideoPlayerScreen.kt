package org.six.series.ui.components.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.six.series.model.content.Content
import org.six.series.profileButtonColors

/**
 * VideoPlayerScreen
 *
 * Compose Desktop does not ship a built-in video player component. This screen
 * provides a fully-styled player UI shell. The actual video playback is handled
 * by embedding a JavaFX MediaView (or VLCJ) inside a SwingPanel.
 *
 * To integrate real playback:
 *   1. Add `uk.co.caprica:vlcj:4.x` (VLCJ) or use JavaFX MediaPlayer.
 *   2. Replace the `VideoSurface` placeholder composable with:
 *        SwingPanel(modifier = Modifier.fillMaxSize()) {
 *            mediaPlayerComponent  // your VLCJ or JFX component
 *        }
 *   3. Wire play/pause/seek callbacks to the media player instance.
 *
 * The controls overlay, progress bar, volume slider and full-screen toggle
 * are fully implemented and ready to be connected to any backend player.
 */
@Composable
fun VideoPlayerScreen(
    content: Content,
    onClose: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }         // 0..1
    var volume by remember { mutableStateOf(0.8f) }          // 0..1
    var showControls by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Auto-hide controls after 3 seconds
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(3000)
            showControls = false
        }
    }

    // Simulate playback progress when playing
    LaunchedEffect(isPlaying) {
        while (isPlaying && progress < 1f) {
            delay(500)
            progress = (progress + 0.001f).coerceAtMost(1f)
        }
        if (progress >= 1f) isPlaying = false
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { showControls = !showControls }
        ) {
            // ── Video surface placeholder ──
            // Replace this Box with your SwingPanel / JavaFX node
            VideoSurface(
                videoUrl = content.videoURL,
                isPlaying = isPlaying,
                modifier = Modifier.fillMaxSize()
            )

            // ── Controls overlay ──
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Top gradient + close/title
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .align(Alignment.TopCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                                )
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Back button
                                IconButton(
                                    onClick = onClose,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                        .pointerHoverIcon(PointerIcon.Hand)
                                ) {
                                    Text("←", color = Color.White, fontSize = 20.sp)
                                }
                                Column {
                                    Text(
                                        content.title,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    if (content.ageRating.isNotEmpty()) {
                                        Text(
                                            "+${content.ageRating}",
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            // Fullscreen toggle
                            IconButton(
                                onClick = { isFullscreen = !isFullscreen },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                    .pointerHoverIcon(PointerIcon.Hand)
                            ) {
                                Text(
                                    if (isFullscreen) "⊡" else "⊞",
                                    color = Color.White, fontSize = 18.sp
                                )
                            }
                        }
                    }

                    // Center play/pause button
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                .clip(CircleShape)
                                .clickable {
                                    isPlaying = !isPlaying
                                    showControls = true
                                }
                                .pointerHoverIcon(PointerIcon.Hand),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isPlaying) "⏸" else "▶",
                                fontSize = 30.sp,
                                color = Color.White
                            )
                        }
                    }

                    // Bottom gradient + seekbar + volume
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                                )
                            )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 24.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Progress bar + timestamps
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    formatTime((progress * (content.duration?.toSecondOfDay() ?: 5400)).toInt()),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Slider(
                                    value = progress,
                                    onValueChange = {
                                        progress = it
                                        showControls = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                    )
                                )
                                Text(
                                    content.duration?.let { formatTime(it.toSecondOfDay()) } ?: "--:--",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Controls row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Skip backward 10s
                                PlayerControlButton("⏮ 10s") {
                                    progress = (progress - 0.01f).coerceAtLeast(0f)
                                    showControls = true
                                }

                                // Play/pause
                                PlayerControlButton(if (isPlaying) "⏸" else "▶", size = 40.dp) {
                                    isPlaying = !isPlaying
                                    showControls = true
                                }

                                // Skip forward 10s
                                PlayerControlButton("10s ⏭") {
                                    progress = (progress + 0.01f).coerceAtMost(1f)
                                    showControls = true
                                }

                                Spacer(Modifier.weight(1f))

                                // Volume
                                Text(
                                    if (isMuted || volume == 0f) "🔇" else if (volume < 0.5f) "🔉" else "🔊",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    modifier = Modifier
                                        .clickable { isMuted = !isMuted }
                                        .pointerHoverIcon(PointerIcon.Hand)
                                )
                                Slider(
                                    value = if (isMuted) 0f else volume,
                                    onValueChange = { volume = it; isMuted = false },
                                    modifier = Modifier.width(120.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color.White,
                                        activeTrackColor = Color.White,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerControlButton(
    label: String,
    size: androidx.compose.ui.unit.Dp = 32.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .background(Color.White.copy(alpha = 0.15f), CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .pointerHoverIcon(PointerIcon.Hand),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = if (size.value >= 40) 20.sp else 12.sp)
    }
}

/**
 * VideoSurface
 *
 * Placeholder for the actual video rendering surface.
 * In a real implementation replace this with a SwingPanel wrapping
 * a VLCJ EmbeddedMediaPlayerComponent or a JavaFX MediaView.
 *
 * Example with VLCJ:
 * ```kotlin
 * SwingPanel(modifier = modifier) {
 *     val factory = MediaPlayerFactory()
 *     val player = factory.mediaPlayers().newEmbeddedMediaPlayer()
 *     val surface = factory.videoSurfaces().newVideoSurface(component)
 *     player.videoSurface().set(surface)
 *     if (isPlaying) player.media().play(videoUrl)
 *     component
 * }
 * ```
 */
@Composable
fun VideoSurface(
    videoUrl: String,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("🎬", fontSize = 64.sp)
            Text(
                "Superficie de video",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 16.sp
            )
            Text(
                "Integra VLCJ o JavaFX MediaPlayer aquí",
                color = Color.White.copy(alpha = 0.35f),
                fontSize = 12.sp
            )
        }
    }
}

private fun formatTime(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s)
    else "%d:%02d".format(m, s)
}
