package org.six.series.ui.components.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import io.github.vinceglb.filekit.PlatformFile
import io.github.vinceglb.filekit.dialogs.FileKitType
import io.github.vinceglb.filekit.dialogs.compose.rememberFilePickerLauncher
import io.github.vinceglb.filekit.readBytes
import kotlinx.coroutines.launch
import org.koin.compose.viewmodel.koinViewModel
import org.six.series.ProfileBlack
import org.six.series.ProfileBlue
import org.six.series.ProfileGray
import org.six.series.ProfileGreen
import org.six.series.ProfilePink
import org.six.series.ProfilePurple
import org.six.series.ProfileRed
import org.six.series.ProfileYellow
import org.six.series.profileButtonColors
import org.six.series.ui.components.viewmodels.ProfileUiState
import org.six.series.ui.components.viewmodels.ProfileViewModel

// Predefined palette with name and color value
data class ColorOption(val name: String, val color: Color, val hexLong: Long)

val profileColorPalette = listOf(
    ColorOption("Gris",     Color(0xFF6A6A69), 0xFF6A6A69L),
    ColorOption("Rosa",     Color(0xFFE2A9F1), 0xFFE2A9F1L),
    ColorOption("Rojo",     Color(0xFFFF3131), 0xFFFF3131L),
    ColorOption("Azul",     Color(0xFF004AAD), 0xFF004AADL),
    ColorOption("Morado",   Color(0xFFCE16FF), 0xFFCE16FFL),
    ColorOption("Negro",    Color(0xFF1A1A1A), 0xFF1A1A1AL),
    ColorOption("Amarillo", Color(0xFFFFDE59), 0xFFFFDE59L),
    ColorOption("Verde",    Color(0xFF7ED957), 0xFF7ED957L),
)

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedFile by viewModel.selectedFile.collectAsState()
    val saveSuccess by viewModel.saveSuccess.collectAsState()
    val scope = rememberCoroutineScope()

    // Local UI state
    var nameField by remember { mutableStateOf("") }
    var imageBytes by remember(selectedFile) { mutableStateOf<ByteArray?>(null) }
    val primaryColor = MaterialTheme.colorScheme.primary
    LaunchedEffect(Unit) {
        viewModel.loadProfile()
    }
    // Load image bytes when file is selected
    LaunchedEffect(selectedFile) {
        imageBytes = selectedFile?.readBytes()
    }

    // Sync name field when profile loads
    LaunchedEffect(uiState) {
        if (uiState is ProfileUiState.Success) {
            nameField = (uiState as ProfileUiState.Success).profile.name
        }
    }

    // File picker launcher
    val launcher = rememberFilePickerLauncher(
        type = FileKitType.Image,
        title = "Selecciona tu foto de perfil"
    ) { file -> viewModel.selectFile(file) }

    // Show snackbar on save
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(saveSuccess) {
        saveSuccess?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissSaveMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { padding ->
        when (uiState) {
            is ProfileUiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            }
            is ProfileUiState.Error -> {
                val msg = (uiState as ProfileUiState.Error).message
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(msg, color = MaterialTheme.colorScheme.error)
                        Button(onClick = { viewModel.loadProfile() }, colors = profileButtonColors()) {
                            Text("Reintentar")
                        }
                    }
                }
            }
            is ProfileUiState.Success -> {
                val profile = (uiState as ProfileUiState.Success).profile
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 32.dp, vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    // Header
                    Text(
                        "Mi Perfil",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // ── Avatar Section ──
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text("Foto de perfil", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

                            // Avatar circle
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                                    .background(primaryColor.copy(alpha = 0.2f))
                                    .border(3.dp, primaryColor, CircleShape)
                                    .clickable { launcher.launch() }
                                    .pointerHoverIcon(PointerIcon.Hand),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatarModel: Any? = when {
                                    imageBytes != null -> imageBytes
                                    !profile.avatarUrl.isNullOrBlank() -> profile.avatarUrl
                                    else -> null
                                }
                                if (avatarModel != null) {
                                    AsyncImage(
                                        model = avatarModel,
                                        contentDescription = "Avatar",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                                    )
                                } else {
                                    // Initials fallback
                                    Text(
                                        text = profile.name.take(2).uppercase(),
                                        fontSize = 36.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryColor
                                    )
                                }
                                // Overlay edit icon
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.25f), CircleShape),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Text(
                                        "✎",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }
                            }

                            Text(
                                "Haz clic en la foto para cambiarla",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (selectedFile != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { viewModel.selectFile(null) },
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = MaterialTheme.colorScheme.error
                                        )
                                    ) { Text("Revertir") }
                                }
                            }
                        }
                    }

                    // ── Name Section ──
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("Nombre del perfil", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            OutlinedTextField(
                                value = nameField,
                                onValueChange = { nameField = it },
                                label = { Text("Nombre") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryColor,
                                    focusedLabelColor = primaryColor
                                )
                            )
                        }
                    }

                    // ── Color Palette Section ──
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text("Color del perfil", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text(
                                "El color que elijas teñirá toda la interfaz de la app",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Color grid (2 rows × 4 cols)
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                profileColorPalette.chunked(4).forEach { row ->
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        row.forEach { option ->
                                            ColorSwatch(
                                                option = option,
                                                isSelected = primaryColor == option.color,
                                                onClick = { viewModel.updateColor(option.hexLong) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }

                            // Preview chip
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Vista previa:", fontSize = 13.sp)
                                Box(
                                    modifier = Modifier
                                        .height(28.dp)
                                        .background(primaryColor, RoundedCornerShape(14.dp))
                                        .padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "Botón de ejemplo",
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    // ── Save Button ──
                    Button(
                        onClick = { viewModel.saveChanges(nameField) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = profileButtonColors()
                    ) {
                        Text("Guardar cambios", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ColorSwatch(
    option: ColorOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else Color.Transparent,
        animationSpec = tween(200)
    )
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(option.color)
                .border(
                    width = if (isSelected) 3.dp else 1.dp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.4f),
                    shape = CircleShape
                )
                .clickable(onClick = onClick)
                .pointerHoverIcon(PointerIcon.Hand),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Text("✓", color = option.color.contrastingColor(), fontWeight = FontWeight.Bold)
            }
        }
        Text(
            option.name,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// Uses androidx.compose.ui.graphics.luminance (imported above)
private fun Color.contrastingColor(): Color =
    if (this.luminance() > 0.5f) Color.Black else Color.White